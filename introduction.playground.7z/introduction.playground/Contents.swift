import UIKit

var str = "Hello, playground"

//let itu sbuah variable yg constant, udh psti, tdk diubah
//aplikasi yg tmpilin tanggal bergnti2
let pemilu = 17
var tanggal=17

tanggal = 14

//kalau let hsl compile lbh cepat krn hslny lbh efisien gk gnti2, dipakai supaya gk ad kesalahan yg hrs ny gk dignti isi variabel, kalau let psti gk gnti

var a = 1, b = 2, c = 3
//emoji : ctrl+cmd+space
var cat = "🐈"
var 🐈 = "kucing"

print(cat) //print psti ad enter
print("hello world")
print("hola",terminator:"") //print tnpa ad enter

//shortcut command : cmd+/ , undo : cmd+z , redo : cmd+shift+z

let suhu: Float = 23.0
var tgl, bulan, tahun: Int
var d:Float, e:Int

//klo di Float, tekan s : struct, klo T : type bisa 32-bit sama 64-bit

//tuple
let birthday: (Int, Int, Int) = (1, 1, 2000)
let person: (nama: String, usia: Int) = ("Ben", 17)

//untuk akses
birthday.0
birthday.1
birthday.2

person.nama
person.usia

//optional : nilai bisa nil
var myVariabel: Int?
print (myVariabel)

myVariabel = 10
myVariabel = nil
myVariabel = 6

// gk bisa == var mySecondVariabel : Int = nil
//unwrapping


//force unwrap -- yakin gk mngkin nil, psti ad nilai , tpi klo nyatanya nil maka akn keluar exception
//myvariabel itu sblmny optional , lalu mw dimasukin ke anotherVariabel yg nilainy pasti ad, maka hrs di unwrap biar bisa diterima (mengartikan psti ad nilainya) dengan '!'
var anotherVariabel = myVariabel!
print(anotherVariabel)

var myCar : String?
myCar = "Bajaj"
if let car = myCar {
    print("I have a car")
} else{
    print("I don't have a car")
}

//operator
2+2
2*2
2/2
2%2
pow(2, 3)

"Nama saya : "+person.nama+" Usia Saya : " + String(person.usia)

var age = "21"

Int(age)

17<21
127<=17
12 == 19
12 != 19

// range operator

for i in 1...3 {
    print(i, terminator:"")
}

for i in 4..<6
{
    print(i)
}

let names = ["Andi","Budi","Charlie","Dennis"]
names.count //tw brp byk array

var string = ""
for i in 0..<names.count{
    print(names[i],terminator:" "+"&")
    string+=names[i]+" "
}
print("\n"+string)

//String
var firstName = "Ben"
var lastName = "Chandra"
var middleName = String()

if lastName.isEmpty{
    print("Tidak punya nama belakang")
}

if middleName.isEmpty{
    print("gk punya")
}

//interpolation
//Hello, firstName lastname

var greeting = "Hello, \(firstName) \(lastName)"
print(greeting)

for character in lastName {
    print(character)
}

let characters: [Character] = ["E", "m","i","l","l","i","o"]

var anotherLastName = String(characters)
print(anotherLastName)

var binus="binus"
//"b-i-n-u-s"

//cek length dari string pake string.characters.count
var flag:Int = 0
for character in binus{
    if (flag==binus.characters.count-1){
        print(character)
    }else {
        print(character,terminator:"-")
    }
    flag+=1
}

flag = 0
for karakter in binus{
    if (flag==binus.count-1){
        print(karakter)
    }else {
        print(karakter,terminator:"-")
    }
    flag+=1
}

for(index,char) in binus.enumerated(){
    //print("sekarang putaran ke \(index),char = \(char)")
    
    if(index==binus.count-1){
        print(char)
    }else{
        print(char,terminator:"-")
    }
}

var newBinus = ""
for character in binus{
    newBinus+=String(character)+"-"
}
newBinus.removeLast()
print(newBinus)
newBinus.remove(at: newBinus.index(before: newBinus.endIndex))//hapus terakhir
print(newBinus)
print(newBinus.remove(at: newBinus.index(newBinus.startIndex, offsetBy:2))) //hapus posisi kedua dari awal
print(newBinus)

//switch
let value = 72
switch value{ //5 dn krng darinya
case ...5:
    print("lima")
case 70...80 where value%2==0 :
    print("tuju puluh")
case 60...: //60 dan lebih
    print("enam puluh")
case 10 :
    print("sepuluh")
case 20 :
    print("dua puluh")
case 40...49:
    print("empat puluh")
case 50, 52, 54:
    print("lima puluh")
default:
    print("gak ada")
}

let zero = 0
for index in stride(from: zero, through: 10, by:2) //mulai dari 0, smpai 10, tambah2 2, from: 0 juga bisa
{
    print(index)
}


var iter = 0
while(iter < 5){
    iter+=1
}

iter = 0
//dowhile
repeat{
    print(iter)
    iter+=1
}while iter<5

//bisa continue, break,

func doSomething(){
    print("I'm doing something")
}
doSomething()

func doSomethingThatReturns()->Double{
    return 4.0
}

//kalau balikin array func doSomethingThatReturns()->[Double]{ return [4.0]

func multiply(angka first:Int, with second:Int)->Int{ //number dn with adalah label, dlm pemanggilan function bisa ad ketearangan tambahan
    return first*second
}

//func kali(_ first:Int,_ second:Int)->Int{ //number dn with adalah label, dlm pemanggilan function bisa ad ketearangan tambahan
//    return first*second
//}

func kali(_ first:Int, _ second:Int?)->Int{
    //    if let apaSih = second{ //kelemahan pake if let, apaSih gk bisa dipakai di luar scope itu
    //        return first * apaSih
    //    }else{
    //        return 0
    //    }
    guard let apaKek = second else{ //guard let berisi apa yg akan dilakukan kalau isinya null
        return 0
    }
    return first*apaKek
}

multiply(angka:4, with:2)
kali(4,nil)
kali(4,1)
