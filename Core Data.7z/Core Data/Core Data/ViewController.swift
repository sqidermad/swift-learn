//
//  ViewController.swift
//  Core Data
//
//  Created by Maria Vanessa Salim on 30/04/19.
//  Copyright © 2019 Maria Vanessa Salim. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    var students: [NSManagedObject] = []
    
    override func viewWillAppear(_ animated: Bool) { //application life cycle. kapan object itu di create
        super.viewWillAppear(animated)
        //FETCH THE DATA
        //STEP 1
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        //STEP 2
        let manageContext = appDelegate.persistentContainer.viewContext
        
        //STEP 3 - bikin obj utk ngefetch
//        let fetchObject = NSFetchRequest //error karena tipenya generic parameter
        let fetchObject = NSFetchRequest<NSManagedObject>(entityName: "Students")

        //STEP 4
        do {
            try students = manageContext.fetch(fetchObject)
        } catch let error as NSError {
            print("Can not fetch the data, due \(error)")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad() // ga ngefetch data dari core data
        configTableView()
    }
    
    func configTableView() {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }

    @IBAction func addStudents(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(title: "Add new student", message: "Input student name", preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] (action) in
          
            guard let textField = alert.textFields?.first, let valueToSave = textField.text
                else {
                    return
            }//apakah si alertnya punya text field apa engga. kalo punya baru ambil valuenya
            self.save(nameOfStudent: valueToSave)
            print("Student data : \(self.students)")
            self.tableView.reloadData()
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addTextField()//munculin textfield di pop up alertnya
        alert.addAction(cancelAction)//munculin cancel di pop up alertnya
        alert.addAction(saveAction)//munculin save di pop up alertnya
        self.present(alert, animated: true, completion: nil)
    }
    //codingan ini baku. stepnya pasti. paling perubahan kalo ada upgrade swift itu pun syntaxnya
    func save(nameOfStudent: String) {
        //step 1
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        //step 2
        let manageContext = appDelegate.persistentContainer.viewContext
        
        //step 3
        let entity = NSEntityDescription.entity(forEntityName: "Students", in: manageContext)!
        let person = NSManagedObject(entity: entity, insertInto: manageContext)
        
        //step 4 utk ngeset value dari atribut di entity yg udah di bikin
        person.setValue(nameOfStudent, forKey: "userName")
        
        //step 5
        do {
            try manageContext.save()
            //update array yg dimiliki
            students.append(person)
        } catch let error as NSError {
            print("Can not sace item, due \(error)")
        }
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return students.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let studentData = students[indexPath.row]
        cell.textLabel?.text = studentData.value(forKey: "userName") as? String
        return cell
    }
}
