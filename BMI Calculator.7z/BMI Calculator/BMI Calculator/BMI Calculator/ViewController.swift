//
//  ViewController.swift
//  BMI Calculator
//
//  Created by Maria Vanessa Salim on 25/04/19.
//  Copyright © 2019 Maria Vanessa Salim. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleBMI: UILabel!
    @IBOutlet weak var segmentLightDark: UISegmentedControl!
    
    @IBOutlet weak var labelWeight: UILabel!
    @IBOutlet weak var sliderWeight: UISlider!
    @IBOutlet weak var labelValueWeight: UILabel!
    
    
    @IBOutlet weak var labelHeight: UILabel!
    @IBOutlet weak var sliderHeight: UISlider!
    @IBOutlet weak var labelValueHeigt: UILabel!
    
    @IBOutlet weak var labelBMI: UILabel!
    @IBOutlet weak var labelValueBMI: UILabel!
    @IBOutlet weak var labelBMIStatus: UILabel!
    
    
    
    var dataBMI:Float = 0.0
    func count() {
        dataBMI = sliderWeight.value / (sliderHeight.value * sliderHeight.value )
        
        labelValueBMI.text = String(format: "%0.2f kg/m2", dataBMI)
        
        if sliderHeight.value == 0 || sliderWeight.value == 0{
            labelValueBMI.text = "0.0 kg/m2"
        } else if sliderHeight.value == 0 && sliderWeight.value == 0 {
            labelValueBMI.text = "0.0 kg/m2"
        }
        statusBMI()
    }
    
    func statusBMI() {
        if dataBMI < 18.5 {
            labelBMIStatus.text = "Underweight"
            labelBMIStatus.textColor = .yellow
        } else if dataBMI >= 18.5 && dataBMI <= 24.9 {
            labelBMIStatus.text = "Normal"
            labelBMIStatus.textColor = .green
        } else if dataBMI >= 25.0 && dataBMI <= 29.9 {
            labelBMIStatus.text = "Overweight"
            labelBMIStatus.textColor = .orange
        } else if dataBMI >= 30.0 {
            labelBMIStatus.text = "Obesse"
            labelBMIStatus.textColor = .red
        } else {
            labelBMIStatus.text = " "
        }
    }
    
    @IBAction func sliderWeightAction(_ sender: UISlider) {
        labelValueWeight.text = "\(round(sliderWeight.value*10)/10) kg"
        count()
    }

    @IBAction func sliderHeightAction(_ sender: UISlider) {
        labelValueHeigt.text = String(format: "%0.2f m", Float(sliderHeight.value))
        count()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func segmentTapped(_ sender: UISegmentedControl) {
        if segmentLightDark.selectedSegmentIndex == 0 {
            
            view.backgroundColor = .white
            titleBMI.textColor = .black
            
            labelWeight.textColor = .black
            labelValueWeight.textColor = .black
            
            labelHeight.textColor = .black
            labelValueHeigt.textColor = .black
            
            labelBMI.textColor = .black
            labelValueBMI.textColor = .black
            
        } else {
            view.backgroundColor = .black
            titleBMI.textColor = .white
            
            labelWeight.textColor = .white
            labelValueWeight.textColor = .white
            
            labelHeight.textColor = .white
            labelValueHeigt.textColor = .white
            
            labelBMI.textColor = .white
            labelValueBMI.textColor = .white
        }
    }
    
    
}

