extension String{ //file terpisah, tidak ada hubungannya dengan si Halaman / view controller
    //A function that return an array containing all the characters from a String
    func getChars() -> [String] {
        let characters = Array(self.characters).map {
            String($0)
        }
        return characters
    }
    
    func nonVowels() -> String {
        var result: String = String()
        
        for letter in Array(self.lowercased().getChars()) {
            switch (letter) {
            case "a", "e", "i", "o", "u":
                continue
            default:
                result += String(letter)
            }
        }
        return result
    }
}

//view controller A

//the string to be tested
let srt = "Hey let's learn Swift!"

srt.getChars() // All the characters from this string
srt.nonVowels() //Removing vowels
