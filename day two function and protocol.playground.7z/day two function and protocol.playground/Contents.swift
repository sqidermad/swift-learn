import UIKit

//function implementation
var stringDefault = "Hello Playground"

func goodMorning() {
    print("\(stringDefault), it's Fun!!")
}

func goodDay(day: Int) {
    if day % 2 == 0 {
        print("\(stringDefault), it's an even number.")
    } else {
        print("\(stringDefault), it's an odd number.")
    }
}

func goodEvening(hour: Int) -> String {
    if hour <= 12 {
        return "Pagi"
    } else if hour > 12 && hour <= 18 {
        return "Sore"
    } else {
        return "Malam"
    }
}

goodMorning() //func biasa
goodDay(day: 5) //func terima parameter integer atau take an argument
goodEvening(hour: 10) //func terima parameter atau take an argument dan return value

//NANO challenge
//buat sebuah function dgn parameter suhu udara (celcius)
//jika suhu udara antara 0-28 cetak "suhu normal"
//jika suhu udara antara 29 - 48 cetak "suhu hangat"
//jika suhu diatas 48 hingga 100 cetak "suhu panas"
//selain itu cetak "undefined"

func suhuUdara(suhu: Int) -> String {
    if suhu >= 0 && suhu <= 28 {
        return "Suhu normal"
    } else if suhu >= 29 && suhu <= 48 {
        return "Suhu hangat"
    } else if suhu >= 48 && suhu <= 100 {
        return "Suhu panas"
    } else {
        return "Undefined"
    }
}

suhuUdara(suhu: 25)

// enum //

enum Planet: Int { //kita harus definisikan dulu dia tuh enum of data type apa
    case merkurius = 0
    case venus = 1
    case earth = 2
    case mars = 3
    case jupiter = 4
    case saturnus = 5
    case uranus = 6
    case neptunus = 7
}

var planet: Planet = .earth
planet.rawValue //dia bisa akses indexnya


// struct & class // gunanya biar bisa jadi bentuk data model yg tujuannya bisa di reuse dimanapun, memiliki karakter & action sendiri
//    persamaan :
//      properti
//      function atau method
//      extentions >> turunan
//      protokol

//Struct always pass by value
struct Person {
    var name: String
    var talkText: String
    var age: Int
//  var name: String?   << ? itu dia berarti bisa nerima null
    
    init(name: String, talkText: String = "Olá", age: Int) {
        self.name = name // self itu kayak this.
        self.talkText = talkText
        self.age = age
    }
    
    //bisa ga sihh init lebih dari satu? yg mana berarti di anggap spt constructor
    //jawabannya gabisa. bakal ada error 'invalid redeclaration of 'init'
//    init(name: String, talkText: String = "Olá") {
//        self.name = name // self itu kayak this.
//        self.talkText = talkText
//        self.age = age
//    }
    
    func talk(){
        print("\(name), \(talkText)")
    }
}

//Creating an instance of the data model

var halo: Person = Person(name: "Vane", talkText: "Learn swift", age: 20)
halo.talk()

class Dog{
    var name: String
    
    init(name: String) {
        self.name = name
    }
}

var toto: Dog = Dog(name: "Sete")
var ende: Dog = toto
print("parent:\(toto.name) ---> child:\(ende.name)")

ende.name = "Rezy"
print("parent:\(toto.name) ---> child:\(ende.name)")

//lebih sering pake class karena mikirin memori tiap ngecreate objectnya

//protokol itu sama kayak abstract class.
//jadi blueprint sebuah object

//nama fungsi yg di blue print biasanya selalu sama dengan nama fungsi yang di daftarin
protocol classRoomDelegate { //blueprint dari halaman 1
    func changeStartTime(newTime: Int)
}

class classRoom { //halaman 1
    var startTime = 10
    var endTime: Int
    var delegate : classRoomDelegate?
    
    init(startTime: Int, endTime: Int) {
        self.startTime = startTime
        self.endTime = endTime
    }
    
    func changeStartTime(newTime: Int) {
        self.delegate?.changeStartTime(newTime: 10) //buat ngasi akses ke org lain nge-override buat akses changeStartTime.
        self.startTime = newTime
    }
}

// ngelakuin spesific action berdasarkan dengan ngambil properti dari halaman 2 yang berdasarkan kondisi dari halaman1
class anotherClassRoom: classRoomDelegate{ // halaman2
    var startTimeNewClass = 10
    func changeStartTime(newTime: Int) {
        if newTime == 100 {
            //
            startTimeNewClass = newTime
        }
    }
}



//NANO CHALLENGE 2
//                                    Temperature conversion table
//                --------------------------------------------------------------------------
//                dari |           F              |        C       |            K           |
//                --------------------------------------------------------------------------|
//                F  |           F              |(F - 32) * 5/9  | (F-32) * 5/9 + 273.15    |
//                C  |     (C * 9/5) + 32       |        C       |       C + 273.15         |
//                K  | (K - 273.15) * 9/5 + 32  |     K-273.15   |           K              |
//                --------------------------------------------------------------------------


//buatlah fungsi konversi suhu utk celcius, farenheit dan kelvin dengan 3 parameter, sbb:
//1. nilai suhu
//2. satuan satuan awal
//3. satuan tujuan
//output : nilai suhu sesuai satuan tujuan

func temperature(dari: String, tempe: Float, tujuan: String ) -> Float {
    if dari == "F" && tujuan == "C" {
        return (tempe - 32) * 5/9
    } else if dari == "F" && tujuan == "K" {
        return (tempe - 32) * 5 / 9 + 273.15
    } else if dari == "F" && tujuan == "F" {
        return tempe
    }
    
    else if dari == "C" && tujuan == "F" {
        return (tempe * 9/5) + 32
    } else if dari == "C" && tujuan == "C" {
        return tempe
    } else if dari == "C" && tujuan == "K" {
        return tempe + 273.15
    }

    
    else if dari == "K" && tujuan == "F" {
        return (tempe - 273.15) * 9/5 + 32
    } else if dari == "K" && tujuan == "C" {
        return tempe - 273.15
    } else if dari == "K" && tujuan == "K" {
        return tempe
    }
    
    return tempe
}

temperature(dari: "C", tempe: 20, tujuan: "K")
